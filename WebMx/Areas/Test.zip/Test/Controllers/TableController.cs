﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WeiCode.ModelDbs;
using WeiCode.Services;

namespace WebProject.Areas.Test.Controllers
{
    public class TableController : BaseLoginController
    {
        // GET: Test/Table
        public ActionResult Index()
        {
            ViewBag.page = new ModelDbSite.site_page
            {
                title = "首页",
                name = "首页"
            };
            return View();
        }
    }
}