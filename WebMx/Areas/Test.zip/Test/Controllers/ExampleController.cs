﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WeiCode.Services;

namespace WebProject.Areas.Test.Controllers
{
    public class ExampleController : BaseLoginController
    {
        // GET: Test/Example
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult NewPanel()
        {
            return View();
        }

        public ActionResult Chart()
        {
            return View();
        }

        public ActionResult HomePage()
        {
            return View();
        }

        public ActionResult Badge()
        {
            return View();
        }

        public ActionResult Button()
        {
            return View();
        }

        public ActionResult Help()
        {
            return View();
        }
    }
}